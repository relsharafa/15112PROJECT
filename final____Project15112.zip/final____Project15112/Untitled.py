# Code designed and written by: Rania ElSharafa
# Andrew ID: relshara
# File Created: November 7, 5:00pm
# Modification History:
# Start           End
# 7/11  05:00pm   7/11  10:00pm
# 8/11  06:00pm   8/11  11:00pm
# 10/11 08:00pm   10/11 10:00pm
# 11/11 05:00pm   11/11 01:00pm
# 12/11 10:30am   12/11 12:30pm
# 15/11 07:00pm   15/11 11:00pm
# 17/11 08:00pm   17/11 09:00pm
# 19/11 05:00pm   19/11 07:00pm
# 21/11 05:00pm   21/11 08:00pm
# 22/11 04:00pm   22/11 11:00pm
# 25/11 12:00pm   25/11 09:00pm
# 26/11 11:04am   26/11 07:20pm

#importing libraries 
import pygame
import os
import random
import time

from pygame.locals import *

#initiating pygame window
pygame.init()
height = 800
width = 600
clock_speed = 150
#setting size for the window
window = pygame.display.set_mode((width, height))
#setting caption
pygame.display.set_caption('Mr.Potato')
#loading gameplay background
background=pygame.image.load("background1.jpg").convert()
highScore=pygame.image.load("background.jpg").convert()

#loading menu and instructions and game over backgrounds
interface=pygame.image.load("interface2.jpg").convert()
instructions=pygame.image.load("instructions.jpg").convert()
gameOverInterface=pygame.image.load("gameover.jpg").convert()

#loading characters of mr.potato for each level
character1=pygame.image.load("char1.png").convert_alpha()
character2=pygame.image.load("char2.png").convert_alpha()
character3=pygame.image.load("char3.png").convert_alpha()
character4=pygame.image.load("char4.png").convert_alpha()
character5=pygame.image.load("char5.png").convert_alpha()
character6=pygame.image.load("char6.png").convert_alpha()
character7=pygame.image.load("char7.png").convert_alpha()
character8=pygame.image.load("char8.png").convert_alpha()
#loading the falling(monsters) objects
monster=pygame.image.load("monster.png").convert()

#loading,playing,setting the voulum background music
music=pygame.mixer.Sound("music.wav")
music.play(-1)
music.set_volume(0.7)
#assigning varibles
game = 1
game_over_menu = 0
highscores_menu = 0
# possible key board input in event.key format
possibleKeyboardChars = [48,49,50,51,52,53,54,55,56,57,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122]
#function to move the character moving horozintaly 
def movePotatoH(potato,direction):
    #initilize the tuples and dictionaries to the key values for the size and the postion,speed of mr.potato
    (sw,sh) = potato['size']
    (px,py) = potato['pos']
    speed = potato['speed']
    #getting the velocity
    velocity = speed*direction
    #cheaking id the player has pressed either left or right keyboard buttons and if so it will
    #move according to the x and y direction that we have caculated
    if direction == -1:
        #cheaking if the character rechead the limit of the borader to avoid losing the charchter
        if px >= 15:
            potato['pos'] = (px + velocity,py)
    elif direction == 1:
        if px <= width-sw-15:
            potato['pos'] = (px + velocity,py)
    
#function to move the character moving vertically
def movePotatoV(potato,direction):
    #initilize the tuples and dictionaries to the key values for the size and the postion,speed of mr.potato
    (sw,sh) = potato['size']
    (px,py) = potato['pos']
    speed = potato['speed']
    velocity = speed*direction
    if direction == -1:
        #cheaking if the character rechead the limit of the borader to avoid losing the charchter
        if py >= 15:
            potato['pos'] = (px, py + velocity)
    elif direction == 1:
        if py <= height-sh-15:
            potato['pos'] = (px, py + velocity)
#function to blit the size color and the postion of the screen text
def blitLabel(screenText, size, color, position):
    text = pygame.font.SysFont(None, size)
    label = text.render(screenText,2,color)
    window.blit(label,position)
def addCharacter(name,pos,size,speed,img):
    #assigning the value of the name in the objects dictionary as a new dictionary
    objects[name]={}
    #giving the character with the name the required attributes position, speed, size, and the image source
    objects[name]['pos'] = pos
    objects[name]['size'] = size
    objects[name]['speed'] = speed
    objects[name]['img']= img
while game == 1:
    #function to set the time of proccesing the game
    clock=pygame.time.Clock()
    menu=1
    name = ""
    #making while loop for the the main menue to be open first
    while menu==1:
        #cheking if we did not go the the game over menu 
        if game_over_menu != 1:
            #assignig varbiles
            main_menu = 1
            instructions_menu = 0
        #cheaking if we went ot the main menu    
        while main_menu == 1:
            #forloop to cheak pygame events like now we want to quit the game
            for event in pygame.event.get():
                # statment to check if the user want to quit the game then we assign varibles
                #that will help us to quit the game
                if event.type is QUIT:
                    game = 0
                    gameplay = 0
                    menu = 0
                    main_menu = 0
                    instructions_menu = 0
                    game_over_menu = 0
                #cheking if the user has pressed with the mouse a specific button 
                elif event.type == MOUSEBUTTONDOWN:
                    #function to get the postion the mouse
                    mousePosition = pygame.mouse.get_pos()
                    #assging the postions to tuples
                    (mx,my) = mousePosition
                    #cheking if a specific button either (start button or main menue button) was pressed
                    #and if so we will start the game
                    if 180 < mx < 395 and 205 < my < 267:
                        gameplay= 1
                        menu = 0
                        main_menu=0
                    #cheking if a specific button either (instruction or main menue button) was pressed
                    #and if so we will go to the instructions window                      
                    if 177 < mx < 396 and 315 < my < 379:
                        main_menu = 0
                        instructions_menu = 1
                    #cheking if a specific button either (highscore menue or main menue button) was pressed
                    #and if so we will go to the highscore window 
                    if 177 < mx < 396 and 427 < my < 491:
                        main_menu = 0
                        highscores_menu = 1
            #function to blit the interface
            window.blit(interface,(0,0))
            #function to flip to diplay the interface
            pygame.display.flip()
        #while loop to cheak for the instruction window
        while instructions_menu == 1:
            for event in pygame.event.get():
                #cheking if the user want to quiz the game
                if event.type is QUIT:
                    #assigning varibles
                    game = 0
                    gameplay = 0
                    menu = 0
                    main_menu = 0
                    instructions_menu = 0
                    game_over_menu = 0
                 #chaking if we moves the mouse button   
                elif event.type == MOUSEBUTTONDOWN:
                    #getting the position of the mouse button
                    mousePosition = pygame.mouse.get_pos()
                    #assing the x and y direction of the mouse into tuples
                    (mx,my) = mousePosition
                    #if statemt to cheak if we pressed specific x and y coordinates and if so
                    #it will satrt the game and assign other varibles to zero so it wont open two window
                    #at the same time
                    if 420 < mx < 574 and 733 < my < 786:
                        gameplay= 1
                        menu = 0
                        instructions_menu=0
                    #if statemt to cheak if we pressed specific x and y coordinates and if so
                    #it will open the main mune and assign other varibles to zero so it wont open two window
                    #at the same time                       
                    if 16 < mx < 170 and 733 < my < 786:
                        main_menu = 1
                        instructions_menu = 0
            #blitting the fliping to diplay the instruction and others windows
            window.blit(instructions,(0,0))
            pygame.display.flip()
        #while loop to cheak if we are at the game over menu
        while game_over_menu == 1:
            name = name
            for event in pygame.event.get():
                #cheaking if the user want to quit the game
                if event.type is QUIT:
                    #assigning varibles
                    game = 0
                    gameplay = 0
                    menu = 0
                    main_menu = 0
                    instructions_menu = 0
                    game_over_menu = 0
                 #chaking if we moves the mouse button   
                elif event.type == MOUSEBUTTONDOWN:
                    #getting position for the mouse
                    mousePosition = pygame.mouse.get_pos()
                    #assign the x y direction into tuples
                    (mx,my) = mousePosition
                    #if statemt to cheak if we pressed specific x and y coordinates and if so
                    #it will open the game play window to play
                    #it will assign varibles that will help us later in other tasks
                    if 420 < mx < 574 and 733 < my < 786:
                        x = open("highscores.txt","a")
                        x.write(name+"-"+str(score)+"\n")
                        x.close
                        gameplay= 1
                        menu = 0
                        instructions_menu=0
                        game_over_menu=0
                    #if statemt to cheak if we pressed specific x and y coordinates and if so
                    #it will open the main menu window 
                    #it will assign varibles that will help us later in other tasks
                    if 16 < mx < 170 and 733 < my < 786:
                        x = open("highscores.txt","a")
                        x.write(name+"-"+str(score)+"\n")
                        x.close
                        main_menu = 1
                        game_over_menu = 0
                #after the user has lose it will appear text for the user to write his name
                #to assign it to the high score window and update the information there      
                if event.type == KEYDOWN:
                    if event.key == K_BACKSPACE:
                        name = name[:-1]
                     
                    else:
                        #cheaking the cases that are allowed to type in the name text 
                        if event.key in possibleKeyboardChars or event.key == K_SPACE:
                            #giving limit for the character to be 12 characthers
                            if len(name) < 12:
                                name += event.unicode
            
            #function to blit the game over interface
            window.blit(gameOverInterface,(0,0))
            #blitting the stats(lives,score,no of parts,level on the screen)
            blitLabel("Lives: " + str(lives), 30, (255,255,255), (20,20))
            blitLabel("Score: " + str(score), 30, (255,255,255), (20,40))
            blitLabel("No. of Parts: " + str(partsCollected), 25, (255,255,255), (455,20))
            blitLabel("Level: " + str(level), 25, (255,255,255), (455,40))
            blitLabel("Your Name: " + name, 40, (0,0,0), (120,300))
            #function to flip the intefrace
            pygame.display.flip()
        #while loop to chek if we are curretnly at the high score menue    
        while highscores_menu == 1:
            for event in pygame.event.get():
                #chek if th eplayer want to quit the game
                if event.type is QUIT:
                    #assigning varibles
                    game = 0
                    gameplay = 0
                    menu = 0
                    main_menu = 0
                    instructions_menu = 0
                    game_over_menu = 0
                    highscores_menu = 0
                 #chaking if we moves the mouse button   
                elif event.type == MOUSEBUTTONDOWN:
                    #geeting postions for the mouse click
                    mousePosition = pygame.mouse.get_pos()
                    #setting tuples to the mouse postions
                    (mx,my) = mousePosition
                    #if statemt to cheak if we pressed specific x and y coordinates and if so
                    #it will satrt the game play 
                    #it will assign varibles that will help us later in other tasks
                    if 420 < mx < 574 and 733 < my < 786:
                        gameplay= 1
                        menu = 0
                        instructions_menu=0
                        game_over_menu=0
                        highscores_menu=0
                    #if statemt to cheak if we pressed specific x and y coordinates and if so
                    #it will open the main menu screen
                    #it will assign varibles that will help us later in other tasks
                    if 16 < mx < 170 and 733 < my < 786:
                        main_menu = 1
                        game_over_menu = 0
                        highscores_menu=0
            
            #function to blit the interface of the high score
            window.blit(highScore,(0,0))
            #setting the high score mune with the lables and seeting to it colors and coordinates
            blitLabel("Highscores Board", 60, (0,0,0), (100,50))

            #opening the high score file to get the updated high scores
            x = open("highscores.txt","r")
            #reading the lines of that file
            data = x.readlines()
            words = []
            scoreBoard = {}
            #for loops to get rid of any other charcter rather than the name and the score in that file
            for line in data:
                words += [line.split("-")]
            for player in words:
                scoreBoard[player[0]] = int(player[1][0:len(player[1])-1])
            sorted_players = sorted(scoreBoard.iteritems(), key=lambda (k, v): (-v, k))[:10]
            #for loop to arange the high score and the name from highest to lowest
            for i in range(len(sorted_players)):
                #setting labels,font size and colors and postions for the high score and the players names
                blitLabel(sorted_players[i][0], 40, (0,0,0), (100,120+(50*i)))
                blitLabel(str(sorted_players[i][1]), 40, (0,0,0), (400,120+(50*i)))
                

            #function to flip 
            pygame.display.flip()
    
    #assignig empty dictionary
    objects= {}
    #pytting dictionaries inside another dicrionaries that will help us later while calling the keys
    #and values later when we need them
    addCharacter("potato",(275,700),(50,80),7,pygame.transform.scale(character1,(50,80)))
    #assging varibles
    monstersOutOfRange=[]
    monsterCount = 0
    monsterID = 0
    partsCollected = 0
    partID = 0
    lifeID = 0
    pBulletID=0
    monsterXHits = 0
    
    gameTime=0
    prevShoot = gameTime
    lives=3
    score = 0
    level = 1
    #while loop to cheak if we starte playing
    while gameplay==1:
        #setting th clock for the speed of the game
        clock.tick(clock_speed)
        #counter for the game time
        gameTime+=1
        name = name
        for event in pygame.event.get():
            #cheaking if the player want to quit the game
            if event.type is QUIT:
                game = 0
                gameplay = 0
            #cheaking if we win the game
            if event.type == KEYDOWN and level == 10:
                    #cheaking if the player pressed backspace to write his name
                    if event.key == K_BACKSPACE:
                        #and if so it will remove the last charcter
                        name = name[:-1]
                    elif event.key == K_RETURN and len(name) > 0:
                        x = open("highscores.txt","a")
                        x.write(name+"-"+str(score)+"\n")
                        x.close
                        gameplay = 0
                        menu = 1
                        main_menu = 1
                    else:
                        if event.key in possibleKeyboardChars or event.key == K_SPACE:
                            if len(name) < 12:
                                name += event.unicode
        #cheaking which key is pressed if it is (down,up,right,left)
        #and if so it will move according to the pressed key
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            movePotatoH(objects['potato'],-1)    
        if keys[pygame.K_RIGHT]:
            movePotatoH(objects['potato'],1)
        if keys[pygame.K_UP]:
            movePotatoV(objects['potato'],-1)   
        if keys[pygame.K_DOWN]:
            movePotatoV(objects['potato'],1)
        #this if statmet for the last level that her we can start
        #using the space key to shoot the monster
        if keys[pygame.K_SPACE] and level == 8 and (gameTime - prevShoot) > 5:
            prevShoot = gameTime
            #getting the values for pos and size from the key in the dictionary
            (px,py) = objects["potato"]['pos']
            (sw,sh) = objects["potato"]['size']
            addCharacter("pBullet"+str(pBulletID),((px+(sw/2)),(py-(sh/2))),(10,10),4,pygame.transform.scale(character1,(10,10)))
            pBulletID+=1
            #settting sound for the bullet when we shoot and the volume of it
            pygame.mixer.music.load("gun2.wav")
            pygame.mixer.music.play(0)
            pygame.mixer.music.set_volume(1)
        #cheking if the key (P) was pressed and the we did win
        #if so it will paused the game 
        if keys[pygame.K_p] and level != 10:
            paused = 1
            #cheking if the game still paused
            while paused == 1:
                #chek if the player want to quit the game and if so
                #it will quit all the screens that was there
                for event in pygame.event.get():
                    if event.type is QUIT:
                        game = 0
                        gameplay = 0
                        paused = 0
                #chaking which key was pressed 
                keys = pygame.key.get_pressed()
                #cheking if the key that was pressed is (R)
                #and if so it will resume the game
                if keys[pygame.K_r]:
                    paused = 0
                #seeting pause text so when we press p it will stop the sreen and
                #appear this text with specific size and color
                blitLabel("Game Paused", 40, (255,255,255), (200,330))
                blitLabel("Press R to resume the GAME!", 30, (255,255,255), (150,380))
                pygame.display.flip()
        #cheking if we did not rached level 8 yet
        if level < 8:
            #cheking if we have less than 2 lives and if so the lives will
            #satrt to fall from the top of the screen
            if gameTime%300==0 and lives < 2:
                lifeID += 1
                #seeting the lives to be fall down with random speed and
                #random positions
                RandomizedXPos = random.randrange(10,550)
                RandomizedSpeed = random.randrange(1,4)
                addCharacter('life'+str(lifeID),(RandomizedXPos, -40),(40,40),RandomizedSpeed,pygame.transform.scale(pygame.image.load("life.png").convert_alpha(),(40,40)))
            #cheking if the game time moudle 160 is zero
            if gameTime%160==0:
                #cheaking if the current level that we are at and according to each level
                #it will assign the partImg 
                if level == 1:
                    partImg = "eye.png"
                elif level == 2:
                    partImg = "nose.png"
                elif level == 3:
                    partImg = "ear.png"
                elif level == 4:
                    partImg ="mouth.png"
                elif level == 5:
                    partImg ="hand.png"
                elif level == 6:
                    partImg ="leg.png"
                elif level == 7:
                    partImg = "hat.png"
                #counter for the parts so we can used them all later in the dictionaries
                partID += 1
                #seeting random postions and speed
                RandomizedXPos = random.randrange(10,550)
                RandomizedSpeed = random.randrange(1,4)
                addCharacter('part'+str(partID),(RandomizedXPos, -40),(40,40),RandomizedSpeed,pygame.transform.scale(pygame.image.load(partImg).convert_alpha(),(40,40)))

                
        #cheking if we have reached that last level
        if gameTime%40==0:
            #chekaing if the monster is there in the objects
            #and if so the small monsters will fall out down from this big monster
            if "monsterX" in objects:
                if gameTime%40==0:
                    #counter for the monster
                    monsterID += 1            
                    #using random so the monters can fall down from random places
                    RandomizedXPos = random.randrange(objects['monsterX']['pos'][0],objects['monsterX']['pos'][0]+objects['monsterX']['size'][0])
                    addCharacter('monster'+str(monsterID),(RandomizedXPos, objects['monsterX']['pos'][1]+230),(40,40),3,pygame.transform.scale(pygame.image.load("monster.png").convert_alpha(),(40,40)))

            else:
                #cheking if we still did not reach the last level
                if level < 8:
                    monsterID += 1            
                    #using random so the monters can fall down from random places
                    RandomizedXPos = random.randrange(10,550)
                    addCharacter('monster'+str(monsterID),(RandomizedXPos, -40),(40,40),3,pygame.transform.scale(pygame.image.load("monster.png").convert_alpha(),(40,40)))

        #cheking if the level is 8 and  the big monster ids not in the objects
        if level == 8 and 'monsterX'  not in objects:
            #assigng varible for the diraction right
            monsterDirection = "right"
            addCharacter('monsterX',(175, -300),(250,250),1,pygame.transform.scale(pygame.image.load("monster.png").convert_alpha(),(250,250)))

            #uploding spund for the big monsterX and setting the voulume with repettion
            monsterSound = pygame.mixer.Sound("monsterLaugh.wav")
            monsterSound.play(-1)
            monsterSound.set_volume(1.4)
        monsterCount = 0
        #bliting the back gound
        window.blit(background,(0,0))
        #letting the charachters togather in the screen the falling monsters and ms.potato
        charsToBeRemoved=[]
        #for loop to remove the charachter when we hit them
        for char in objects:
            #cheaking if monters is in the dictionary 
            if char[0:7] == "monster":
                #checking if the postions of the character is greater than the hight of the screen
                if not objects[char]['pos'][1] > height:
                    #cheking if chat is monster X
                    if char == "monsterX":
                        if objects[char]['pos'][1] < 100:
                            #setting the postion and speed for monster x
                            objects[char]['pos'] = (objects[char]['pos'][0],objects[char]['pos'][1]+objects[char]['speed'])
                        else:
                            #cheking if the monster direction is to right
                            if monsterDirection == "right":
                                #if so it will cheak if the position is greater than 200
                                if objects[char]['pos'][0] > 300:
                                    #if so the monster will go to the right and so on
                                    monsterDirection = "left"
                                #however if the monster is in the left side then it will go ti the right direction    
                                else:
                                    objects[char]['pos'] = (objects[char]['pos'][0]+objects[char]['speed'],objects[char]['pos'][1])
                            elif monsterDirection == "left":
                                if objects[char]['pos'][0] < 50:
                                    monsterDirection = "right"
                                else:
                                    objects[char]['pos'] = (objects[char]['pos'][0]-objects[char]['speed'],objects[char]['pos'][1])
                    else:
                        
                        objects[char]['pos'] = (objects[char]['pos'][0],objects[char]['pos'][1]+objects[char]['speed'])
                    window.blit(objects[char]['img'], objects[char]['pos'])
                    monsterCount+= 1
                    #her when we want to add to the score so when one monster go down 5 will counut and so on
                else:
                    charsToBeRemoved += [char]
                    score+=5
                #cheking if the mr potao hit the monster (when the postion of mr.potato come to the position
                #of the monster so it will lose lives    
                if (objects[char]['pos'][0]+objects[char]['size'][0]) >= objects['potato']['pos'][0] >= (objects[char]['pos'][0]- objects['potato']['size'][0]):
                    if (objects[char]['pos'][1]+objects[char]['size'][1]) >= objects['potato']['pos'][1] >= (objects[char]['pos'][1]- objects['potato']['size'][1]):
                        lives -=1
                        #uploading sound when mr.potato lose lives
                        pygame.mixer.music.load("pain.wav")
                        pygame.mixer.music.play(0)
                        charsToBeRemoved += [char]
                #for loop to chek inside the objects
                for o in objects:
                    #if bullet is in side the obejts
                    if o[0:7] == "pBullet":
                        #cheak if the pullets hit the big and small monster as if the postion of the pullet
                        #and the postion of the monsters are the same if so the monster will be killed and the score
                        #will count to 50 and so on
                        if (objects[o]['pos'][0]+objects[o]['size'][0]) >= objects[char]['pos'][0] >= (objects[o]['pos'][0]- objects[char]['size'][0]):
                            if (objects[o]['pos'][1]+objects[o]['size'][1]) >= objects[char]['pos'][1] >= (objects[o]['pos'][1]- objects[char]['size'][1]):
                                if char == "monsterX":
                                    monsterXHits += 1
                                    score += 50
                                    objects[o]['pos'] = (0,-3000)
                                    #cheaking if we killed the monster by more than 400 hits so we will win and a sound
                                    #will be uploded for the wining the game by deafeting monsterX
                                    if monsterXHits > 400:
                                        objects[char]['pos'] = (0,3000)
                                        level = 10
                                        pygame.mixer.music.load("win.wav")
                                        pygame.mixer.music.play(0)
                                        monsterSound.stop()
                                else:
                                    score += 20                                  
                                    objects[char]['pos'] = (0,3000)
                                    objects[o]['pos'] = (0,-3000)
            #cheaking if the falling stuff are one of the parts (cheaking if part is inside the char)
            elif char[0:4] == 'part':
                #her we are cheaking if mr.potato has collect the parts or not and if he did not the
                #charachtes will fall down and other parts will come again
                if not objects[char]['pos'][1] > height:
                    objects[char]['pos'] = (objects[char]['pos'][0],objects[char]['pos'][1]+objects[char]['speed'])
                    window.blit(objects[char]['img'], objects[char]['pos'])
                else:
        
                    charsToBeRemoved += [char]
                    score+=10
                #her we are cheaking if the mr potato collect one of the characthers an if so
                #parts collectd that are on the screen will increase and there will be sound uploded
                #when it colect the parts
                if (objects[char]['pos'][0]+objects[char]['size'][0]) >= objects['potato']['pos'][0] >= (objects[char]['pos'][0]- objects['potato']['size'][0]):
                    if (objects[char]['pos'][1]+objects[char]['size'][1]) >= objects['potato']['pos'][1] >= (objects[char]['pos'][1]- objects['potato']['size'][1]):
                        partsCollected += 1
                        charsToBeRemoved += [char]
                        pygame.mixer.music.load("collect.wav")
                        pygame.mixer.music.play(0)
                        pygame.mixer.music.set_volume(1.5)
            #the same thig happen with lives 
            elif char[0:4] == 'life':
                if not objects[char]['pos'][1] > height:
                    objects[char]['pos'] = (objects[char]['pos'][0],objects[char]['pos'][1]+objects[char]['speed'])
                    window.blit(objects[char]['img'], objects[char]['pos'])
                else:
                    charsToBeRemoved += [char]
                if (objects[char]['pos'][0]+objects[char]['size'][0]) >= objects['potato']['pos'][0] >= (objects[char]['pos'][0]- objects['potato']['size'][0]):
                    if (objects[char]['pos'][1]+objects[char]['size'][1]) >= objects['potato']['pos'][1] >= (objects[char]['pos'][1]- objects['potato']['size'][1]):
                        charsToBeRemoved += [char]
                        lives += 1
                        pygame.mixer.music.load("collect.wav")
                        pygame.mixer.music.play(0)
                        pygame.mixer.music.set_volume(1.5)
            #cheking if chat is potato
            elif char=='potato':
                #cheaking if we collects (this amout of parts and we still did not win)
                
                if partsCollected == 10 and level < 8:
                    #and if so the level will increase
                    level +=1
                    intermission = 1
                    while intermission == 1:
                        #cheking if the palyer want ot quit the game
                        for event in pygame.event.get():
                            if event.type is QUIT:
                            #assigning varibles
                                game = 0
                                gameplay = 0
                                menu = 0
                                main_menu = 0
                                instructions_menu = 0
                                game_over_menu = 0
                                highscores_menu = 0
                            keys = pygame.key.get_pressed()
                            if keys[pygame.K_RETURN]:
                                intermission = 0
                        window.blit(background,(0,0))
                        #cheking if the reached the last level and we won
                        if level == 8:
                            #showing those charachters with specific color and size to be displayed
                            #on the screen
                            blitLabel("Congratulations!", 60, (255,255,255),(130,200))
                            blitLabel("You have reached level " + str(level), 40, (255,255,255),(125,340))
                            blitLabel("AKA the MONSTER X LEVEL", 40, (255,255,255),(100,380))
                            blitLabel("shoot at him by pressing SPACE", 40, (255,255,255),(100,420))
                            blitLabel("PRESS ENTER TO GO TO BATTLE!", 35, (255,255,255),(110,460))
                            pygame.display.flip()
                            #else if we did not reached the last level
                        else:
                            #we will show those characters that will be showen on the screen
                            #when we finsh each level with specific color and size and postion
                            blitLabel("Congratulations!", 60, (255,255,255),(130,200))
                            blitLabel("You have reached level " + str(level), 40, (255,255,255),(125,340))
                            blitLabel("Press ENTER to go to the next level!", 35, (255,255,255),(110,390))
                            pygame.display.flip()                       
                    partsCollected = 0
                    #cheking at what level we are and accoring to this level mr.potato will
                    #change his characheter with the parts that was collect
                if level == 2:
                    objects['potato']['img']=pygame.transform.scale(character2,objects['potato']['size'])
                elif level == 3:
                    objects['potato']['img']=pygame.transform.scale(character3,objects['potato']['size'])
                elif level == 4:
                    objects['potato']['img']=pygame.transform.scale(character4,objects['potato']['size'])
                elif level == 5:
                    objects['potato']['img']=pygame.transform.scale(character5,objects['potato']['size'])
                elif level == 6:
                    objects['potato']['img']=pygame.transform.scale(character6,objects['potato']['size'])
                elif level == 7:
                    objects['potato']['img']=pygame.transform.scale(character7,objects['potato']['size'])
                elif level == 8:
                    objects['potato']['img']=pygame.transform.scale(character8,objects['potato']['size'])
                window.blit(objects[char]['img'], objects[char]['pos'])
            elif char[0:7] == "pBullet" :
                if not objects[char]['pos'][1] < 0:
                    objects[char]['pos'] = (objects[char]['pos'][0],objects[char]['pos'][1]-objects[char]['speed'])
                    if char not in charsToBeRemoved:
                        window.blit(objects[char]['img'], objects[char]['pos'])
                else:
                    charsToBeRemoved += [char]
                                                                 
        #bliting the lables(lives,score,no of parts,level on the screen with specific color size postion
        blitLabel("Lives: " + str(lives), 30, (255,255,255), (20,20))
        blitLabel("Score: " + str(score), 30, (255,255,255), (20,40))
        blitLabel("No. of Parts: " + str(partsCollected), 25, (255,255,255), (455,20))
        blitLabel("Level: " + str(level), 25, (255,255,255), (455,40))
        #cheking if we have reached level 10 and if so those charachters will appear
        if level == 10:
            blitLabel("YOU BEAT MONSTER X", 50, (0,0,0), (105,300))
            blitLabel("Type your name", 50, (0,0,0), (150,350))
            blitLabel("Press Enter for Main Menu", 50, (0,0,0), (90,400))
            blitLabel("Your Name: " + name, 50, (0,0,0), (65,500))
        
        for character in charsToBeRemoved:
            del objects[character]
        #cheking if lives are 0
        if lives == 0:
            #uplading sound for the losing
            pygame.mixer.music.load("dying.wav")
            pygame.mixer.music.play(0)
            pygame.mixer.music.set_volume(2)
            if "monsterX" in objects:
                monsterSound.stop()
            
            gameplay = 0
            menu = 1
            game_over_menu = 1
        #disaplying the charchter and back ground
        pygame.display.flip()
    



#function to quit pygame 
pygame.quit()
