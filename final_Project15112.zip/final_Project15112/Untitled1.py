import pygame
import os
import random

from pygame.locals import *

#initiating pygame window
pygame.init()
height = 800
width = 600
#setting size for the window
window = pygame.display.set_mode((width, height))
#setting caption
pygame.display.set_caption('Mr. Potato')
#loading background
background=pygame.image.load("background.jpg").convert()
#loading and playing background music
music=pygame.mixer.Sound("music.wav")
music.play(-1)
music.set_volume(0.5)

game = 1

while game == 1:
    window.blit(background,(0,0))
    for event in pygame.event.get():
        if event.type is QUIT:
            game = 0
            
    pygame.display.flip()
    



pygame.quit()
